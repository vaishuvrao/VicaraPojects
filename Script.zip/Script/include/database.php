<?php
	mysql_connect("localhost","root","") or die('Error : Database not connected...');
	mysql_select_db("mytube") or die('Error : database not found...');
?>