<script>
	function notblank()
	{
		var searchterm = document.getElementById('searchterm');
		if(searchterm.value=="" || searchterm.value=="search video, wallpapers & songs")
		{
			alert('Enter some key words for search.');
			searchterm.focus();
			return false;
		}
	}
</script>
<LINK rel="SHORTCUT ICON" href="images/icon.png">
<link href="css/main1.css" type="text/css" rel="stylesheet" />
<form action="search.php" name="search" method="post">
<table cellpadding="5" class="indextab" cellspacing="0"  width="100%" height="100%" >
  <tr> 
    <td rowspan="3"> <img  src="images/mytubelogo.png"/></td>
    <th rowspan="3" width="60%"> Upload your<br />
      <a class="keysearch" href="login.php?u=vid">Video</a><br />
      <a class="keysearch" href="login.php?u=wall">Wallpapers</a><br />
      <a class="keysearch" href="login.php?u=song">Songs</a> 
    </th>
    <td colspan="2" width="30%"> <span class="keysearch1">Today 
      :</span> <span style="text-decoration:blink"> <?php echo date("dS M Y").","; ?> 
      <?php $day =date("D"); if($day=='Tue'){ $day = $day."s"; } else if($day=='Wed'){ $day = $day."nes"; } else if($day=='Thu'){ $day = $day."rs"; } else if($day=='Sat'){ $day = $day."ur"; } echo $day."day"; ?></span> </td>
  </tr>
  
  <tr> 
    <td colspan="2" align="left" style="background:#B76004;-moz-border-radius:5px;-moz-box-shadow:0px 0px 5px 0px #000000; padding:5px; color:#000000; text-shadow:1px 1px 1px #FFFFFF; font-weight:bold;"> 
      <input type="radio" name="search" id="video" value="video" checked="checked" />
      Video&nbsp; <input type="radio" name="search" id="wallpapers" value="wallpapers"/>
      Wallpapers&nbsp; <input type="radio" name="search" id="songs" value="songs" />
      Songs&nbsp; <input type="radio" name="search" id="all" value="all"/>
      All </td>
  </tr>
  <tr> 
    <td> <input type="text" name="searchterm" id="searchterm" value="search video, wallpapers & songs" onFocus="if(this.value=='search video, wallpapers & songs'){this.value='';}" onBlur="if(this.value==''){this.value='search video, wallpapers & songs';}" style="padding:3px;" class="inputsr" size="35" /> 
    </td>
    <td> <input type="submit" style="padding:3px;" name="submit" value="" id="submit" class="searchbnt" onclick="return notblank();"/> 
    </td>
  </tr>
</table>
</form>
