<table cellpadding="3" border="0" style="border-bottom:1px solid #000000;" cellspacing="0"  width="100%" height="100%" >
<tr>
<td width="13%" rowspan="2" align="left">
	<img  src="../images/mytubelogo.png"/></td>
<td width="65%" rowspan="2" align="center" valign="middle">Wel-come <?php echo $_SESSION['username']; ?></td>
<td valign="bottom">
	<span class='keysearch1'>Today :</span> 
	<span style="text-decoration:blink"> <?php echo date("dS M Y").","; ?>
	<?php $day =date("D"); if($day=='Tue'){ $day = $day."s"; } else if($day=='Wed'){ $day = $day."nes"; } else if($day=='Thu'){ $day = $day."rs"; } else if($day=='Sat'){ $day = $day."ur"; } echo $day."day"; ?></span>
	</td>
</tr>
<tr>
	<th width="22%">
	<a href="logout.php" style="text-decoration:none; cursor:pointer; "><img src="../images/logout.png" border="0"></a>
	</th>
</tr>
</table>