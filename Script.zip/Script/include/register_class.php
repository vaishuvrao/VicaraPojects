<?php
class general
{
	public function insert($firstname,$lastname,$gender,$birthdate,$email,$country,$postalcode,$username,$password,$sec_ques,$sec_ans)
	{
		$ins="INSERT INTO register(firstname,lastname,gender,birthdate,email,country,postalcode,username,password,sec_ques,sec_ans,status) 
		VALUES('$firstname','$lastname','$gender','$birthdate','$email','$country','$postalcode','$username','$password','$sec_ques','$sec_ans','1')";
		mysql_query($ins) or die('Insert user data problem..');
		return 1;	
	}
	public function checkuser($username)
	{
		$selid="SELECT * FROM register WHERE username='$username'";
		$result = mysql_query($selid) or die('userid select problem..');
		$num=mysql_num_rows($result);
		if($num>0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	public function update($id,$firstname,$lastname,$gender,$birthdate,$email,$country,$postalcode,$sec_ques,$sec_ans)
	{
		$dataupd="UPDATE register SET firstname='$firstname',lastname='$lastname',gender='$gender',birthdate='$birthdate',
		email='$email',country='$country',postalcode='$postalcode',sec_ques='$sec_ques',sec_ans='$sec_ans' WHERE id='$id'";
		mysql_query($dataupd) or die('Update user data problem..');
	}
	public function updatepassword($npassword,$id,$oldpass)
	{
		$selrow="SELECT * FROM register WHERE id='$id' AND password='$oldpass'";
		$result=mysql_query($selrow);
		$num=mysql_num_rows($result);
		if($num>0)
		{
			$update = "UPDATE register SET password='$npassword' WHERE id='$id' AND password='$oldpass'";
			mysql_query($update) or die('Error : select user password and old password');
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public function datadelete($id)
	{
		$deldata="DELETE FROM register WHERE id='$id'";
		mysql_query($deldata) or die('Delete user data Problem..');
	}
	public function selall()
	{
		$sel="SELECT * FROM register";
		$result=mysql_query($sel) or die('Select All user query problem..');
		$num=mysql_num_rows($result);
		if($num>0)
		{
			$data=array();
			while($rows=mysql_fetch_array($result))
			{
				$data=$rows;
			}
			return $data;
		}
		else
		{
			return 0;
		}
	}
	public function selwithid($id)
	{
		$selid="SELECT * FROM register WHERE id='$id'";
		$result=mysql_query($selid) or die('select user with id query problem..');
		$rows=mysql_fetch_array($result);
		return $rows;
	}
	public function forgetuser($username,$email,$secques,$secans)
	{
		$selid="SELECT * FROM register WHERE username='$username' AND email='$email' AND sec_ques='$secques' 
				AND sec_ans='$secans'";
		$result=mysql_query($selid) or die('select user with id query problem..');
		$num=mysql_num_rows($result);
		if($num>0)
		{
			$rows=mysql_fetch_array($result);
			$_SESSION['userid']=$rows['id'];
			$_SESSION['user']=$rows['username'];
			$_SESSION['password']=$rows['password'];
			$_SESSION['username']=$rows['firstname']." ".$rows['lastname'];
			return 1;
		}
		else
		{
			return 0;
		}

	}
	public function userauthority($username,$password)
	{
		$selid="SELECT * FROM register WHERE username='$username' AND password='$password'";
		$result=mysql_query($selid) or die('select user with id query problem..');
		$num=mysql_num_rows($result);
		if($num>0)
		{
			$rows=mysql_fetch_array($result);
			$_SESSION['user']=$rows['username'];
			$_SESSION['userid']=$rows['id'];
			$_SESSION['username']=$rows['firstname']." ".$rows['lastname'];
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
?>