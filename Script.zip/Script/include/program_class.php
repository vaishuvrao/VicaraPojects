<?php
class general_class
{
    public function update($id,$table,$title,$description)
	{
	     $dataupd= "UPDATE INTO $table SET title='$title',description='$description' WHERE id='$id'";
		 mysql_query($dataupds) or die('uploaded video upload..');
	}
	public function datadelete($id,$table)
	{
		$deldata="DELETE FROM $table WHERE id='$id'";
		mysql_query($id) or  die('delete video..');
	}	 
	public function insert($table,$title,$url,$description)
	{
		$ins="INSERT INTO $table(title,url,description,status) VALUES 
			 ('$title','$url','$description','1')";
		mysql_query($ins) or die('Insert user data problem..');
		return 1;	
	}
	public function select5record($table,$up,$lp)
	{
		$sel="SELECT * FROM $table LIMIT $up,$lp";
		$result=mysql_query($sel) or die('Select query problem.');
		$num=mysql_num_rows($result);
		if($num>0)
			{
				$data=array();
				while($row=mysql_fetch_array($result))
				{
					$data[]=$row;
				}
				return $data;
			}
		else
			{
				return 0;
			}
	}
	public function searchdata($table,$data)
	{
		$last=10;
		if($table=='video')
		{
			$last=5;
		}
		$sel="SELECT * FROM $table WHERE title LIKE '%$data%' OR 
				description LIKE '%$data%' LIMIT 0,$last";
		$result=mysql_query($sel) or die('Select query problem.');
		$num=mysql_num_rows($result);
		if($num>0)
			{
				$data=array();
				while($row=mysql_fetch_array($result))
				{
					$data[]=$row;
				}
				return $data;
			}
		else
			{
				return 0;
			}
	}
	public function searchbyalpha($table,$data)
	{
		$last=10;
		if($table=='video')
		{
			$last=5;
		}
		$sel="SELECT * FROM $table WHERE title LIKE '$data%' LIMIT 0,$last";
		$result=mysql_query($sel) or die('Select query problem.');
		$num=mysql_num_rows($result);
		if($num>0)
			{
				$data=array();
				while($row=mysql_fetch_array($result))
				{
					$data[]=$row;
				}
				return $data;
			}
		else
			{
				return 0;
			}
	}
}
?>