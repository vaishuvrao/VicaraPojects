<?php 
$ext=$_GET['filename'];
header ("Content-Type:application/force-download"); 
header ("Content-Disposition: attachment; filename=".$ext);
$file=$ext; 
@readfile($file); 	
exit;
?>