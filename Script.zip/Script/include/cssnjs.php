<link href="../css/main1.css" rel="stylesheet" type="text/css"/>
<link type="text/css" href="usermenu/menu.css" rel="stylesheet" />
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="usermenu/menu.js"></script>
<script type="text/javascript" src="video/swfobject.js"></script>
<LINK rel="SHORTCUT ICON" href="../images/icon.png">
