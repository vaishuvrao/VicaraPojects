<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style>
	li
	{
	  text-align:justify;
	  font-size:20px;
	}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: All terms and conditions</title>
</head>
<body>
<p align="justify">
<ul>
<li> <strong><font size="5">Service</font></strong> 
  <ul>
  	<li>These Terms of Service apply to all users of the Service, including 
    users who are also contributors of Content on the Service. &#8220;Content&#8221; 
    includes the text, software, scripts, graphics, photos, sounds, music, videos, 
    audiovisual combinations, interactive features and other materials you may 
    view on, access through, or contribute to the Service. The Service includes 
    all aspects of MyTube, including but not limited to all products, software 
    and services offered via the MyTube website, such as the MyTube channels, 
    the MyTube &quot;Embeddable Player,&quot; the MyTube &quot;Uploader&quot; 
    and other applications.</li>
    <li>The Service may contain links to third party websites that are not owned or 
    controlled by MyTube. MyTube has no control over, and assumes no responsibility 
    for, the content, privacy policies, or practices of any third party websites. 
    In addition, MyTube will not and cannot censor or edit the content of any 
    third-party site. By using the Service, you expressly relieve MyTube from 
    any and all liability arising from your use of any third-party website.</li><li>
    Accordingly, we encourage you to be aware when you leave the Service and to 
    read the terms and conditions and privacy policy of each other website that 
    you visit.<br />
	</li></ul>
<br/>	
<li> <strong><font size="5">MyTube Accounts</font></strong> 
  <ul>
    <li> In order to access some features of the Service, you will have to create 
      a MyTube or account. You may never use another's account without 
      permission. When creating your account, you must provide accurate and complete 
      information. You are solely responsible for the activity that occurs on 
      your account, and you must keep your account password secure. You must notify 
      MyTube immediately of any breach of security or unauthorized use of your 
      account.</li>
    <li> Although MyTube will not be liable for your losses caused by any unauthorized 
      use of your account, you may be liable for the losses of MyTube or others 
      due to such unauthorized use.</li>
    
  </ul>
</li>
	<br/>
<li> <strong><font size="5">General Use of the Service&#8212;Permissions and Restrictions</font></strong> 
  <ul><li>
    MyTube hereby grants you permission to access and use the Service as set 
    forth in these Terms of Service, provided that:</li><li>
    You agree not to distribute in any medium any part of the Service or the Content 
    without MyTube's prior written authorization, unless MyTube makes available 
    the means for such distribution through functionality offered by the Service 
    (such as the Embeddable Player).</li><li>
    You agree not to alter or modify any part of the Service.</li><li>
    You agree not to access Content through any technology or means other than 
    the video playback pages of the Service itself, the Embeddable Player, or 
    other explicitly authorized means MyTube may designate.</li><li>
    You agree not to use the Service for any of the following commercial uses 
    unless you obtain MyTube's prior written approval: </li><ol><li>
    the sale of access to the Service;</li><li>
    the sale of advertising, sponsorships, or promotions placed on or within 
    the Service or Content; or </li><li>
    the sale of advertising, sponsorships, or promotions on any page of an 
    ad-enabled blog or website containing Content delivered via the Service, unless 
    other material not obtained from MyTube appears on the same page and is of 
    sufficient value to be the basis for such sales.</li></ol><li>
    Prohibited commercial uses do not include: </li><ol><li>
    uploading an original video to MyTube, or maintaining an original channel 
    on MyTube, to promote your business or artistic enterprise;</li><li>
    showing MyTube videos through the Embeddable Player on an ad-enabled blog 
    or website, subject to the advertising restrictions set forth above in Section D; or
    any use that MyTube expressly authorizes in writing.</li><li>
    (For more information about what constitutes a prohibited commercial use, 
    see our FAQ.)</li></ol><li>
    If you use the Embeddable Player on your website, you may not modify, build 
    upon, or block any portion or functionality of the Embeddable Player, including 
    but not limited to links back to the MyTube website.</li><li>
    If you use the MyTube Uploader, you agree that it may automatically download 
    and install updates from time to time from MyTube. These updates are designed 
    to improve, enhance and further develop the Uploader and may take the form 
    of bug fixes, enhanced functions, new software modules and completely new 
    versions. You agree to receive such updates (and permit MyTube to deliver 
    these to you) as part of your use of the Uploader.</li><li>
    You agree not to use or launch any automated system, including without limitation, 
    &quot;robots,&quot; &quot;spiders,&quot; or &quot;offline readers,&quot; that 
    accesses the Service in a manner that sends more request messages to the MyTube 
    servers in a given period of time than a human can reasonably produce in the 
    same period by using a conventional on-line web browser. Notwithstanding the 
    foregoing, MyTube grants the operators of public search engines permission 
    to use spiders to copy materials from the site for the sole purpose of and 
    solely to the extent necessary for creating publicly available searchable 
    indices of the materials, but not caches or archives of such materials. MyTube 
    reserves the right to revoke these exceptions either generally or in specific 
    cases. You agree not to collect or harvest any personally identifiable information, 
    including account names, from the Service, nor to use the communication systems 
    provided by the Service (e.g., comments, email) for any commercial solicitation 
    purposes. You agree not to solicit, for commercial purposes, any users of 
    the Service with respect to their Content.</li><li>
    In your use of the Service, you will comply with all applicable laws.</li><li>
    MyTube reserves the right to discontinue any aspect of the Service at any 
    time. </li>
</ul>
</p>
</body>
</html>
