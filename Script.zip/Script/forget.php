<?php
	session_start();
	include("include/database.php");
	include("include/register_class.php");
	$obj=new general();
	$msg='';
	if(isset($_POST['next']) && $_POST['next']=='Next >>')
	{
		$username=$_POST['username'];
		$email=$_POST['email'];
		$secques=$_POST['securityques'];
		$secans=$_POST['securityans'];
		if($username!="" && $email!="" && $secques!="" && $secans!="")
		{
			$result=$obj->forgetuser($username,$email,$secques,$secans);
			if($result==1)
			{
				header('location:user/changepassword.php');
				exit;
			}
			else
			{
				$msg='Your entered information was wrong.';
			}
		}
		else
		{
			$msg='Enter your following information.';
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: user forget password</title>
</head>
<body>
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("include/head.php"); ?></td>
		</tr>
		<tr>
			<td>
				<form action="" method="post" name="forget">
				<table style="margin:auto;"  cellpadding="0" class="uploadtab" cellspacing="4">
				<tr>
					<th class="headth" colspan="3">Forget Password</th>
				</tr>
				<tr>
							<th align="right">User Name</th>
							<td><input type="text" name="username" id="12" tabindex="12" size="35" class="inputtype" /></td>
							<td id="compalsory">*</td>
						</tr>
					<tr>
						<th align="right">E-mail</th>
						<td><input type="text" class="inputtype" name="email"  size="35"  id="email"/></td>
						<td id="compalsory">*</td>
					</tr>
					<tr>
							<th align="right">Security Question</th>
							<td><select id="11" tabindex="11" class="inputtype" name="securityques">
								<option value="" selected="selected">- Select Security question -</option>
											<option value="Where did you meet your spouse?">Where did you meet 
											your spouse?</option>
											<option value="What was the name of your first school?">What was the 
											name of your first school?</option>
											<option value="Who was your childhood hero?">Who was your childhood 
											hero?</option>
											<option value="What is your favorite passtime?">What is your favorite 
											passtime?</option>
											<option value="Which is your favorite sports team?">What is your favorite 
											sports team?</option>
											<option value="What is your father middle name?">What is your father's 
											middle name?</option>
											<option value="What was your high school mascot?">What was your high 
											school mascot?</option>
											<option value="What make was your first car or bike?">What make was 
											your first car or bike?</option>
								</select>
							</td>
							<td id="compalsory">*</td>
						</tr>
						<tr>
							<th align="right">Security Answer</th>
							<td><input type="text" name="securityans"  size="35"  id="12" tabindex="12" class="inputtype" /></td>
							<td id="compalsory">*</td>
						</tr>
					<tr>
						<th></th>
						<td align="right"><input type="reset" class="cancelbtn" name="reset" id="reset" value="Cancel" />
						<input class="submitbtn" type="submit" name="next" id="submit" value="Next >>" />								
						 </td>
					</tr>
				</table>
				</form>				
			</td>
		</tr>
</table>
</body>
</html>
