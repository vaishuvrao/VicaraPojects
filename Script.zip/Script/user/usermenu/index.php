<body style="margin:0; padding:0">
<div id="menu">
    <ul class="menu">
        <li><a href="index.php"><span>Home</span></a></li>
        <li><a href="#"><span>Video</span></a>
            <div>
				<ul>
					<li><a href="video.php"><span>View</span></a></li>
					<li><a href="videoupload.php"><span>Upload</span></a></li>
				</ul>
			</div>
        </li>
		<li><a href="#"><span>Wallpapers</span></a>
            <div>
				<ul>
					<li><a href="wallpapers.php"><span>View</span></a></li>
					<li><a href="wallpaperupload.php"><span>Upload</span></a></li>
				</ul>
			</div>
        </li>
		<li><a href="#"><span>Songs</span></a>
            <div>
				<ul>
					<li><a href="songs.php"><span>View</span></a></li>
					<li><a href="songsupload.php"><span>Upload</span></a></li>
				</ul>
			</div>
        </li>
			<li><a href="profile.php"><span>Profile</span></a></li>
		 <li><a href="changepassword.php"><span>Change Password</span></a></li>
    </ul>
</div>
<div style="display:none"><a href="http://apycom.com/" rel="nofollow">#</a></div>
</body>