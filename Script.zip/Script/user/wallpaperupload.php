<?php
	include("session_chek.php");
	include("../include/database.php");
	include("../include/program_class.php");
	$obj=new general_class();
	if(isset($_POST['submit']) && $_POST['submit']=='Upload')
	{
		$wallpapertitle = $_POST['wallpapertitle'];
		$wallpaperdes = $_POST['wallpaperdes'];
		if($_FILES['wallpaper']['type']=='image/png' || $_FILES['wallpaper']['type']=='image/jpg' || 
		$_FILES['wallpaper']['type']=='image/gif' || $_FILES['wallpaper']['type']=='image/jpeg')
		{
			if($_FILES['wallpaper']['size']<20000)
			{
				$msg="Size of uploded file is large than limit 1Mb.";
			}
			else
			{
				$filename = $_FILES['wallpaper']['name'];
				$temp_name = $_FILES['wallpaper']['tmp_name'];
				$newname = 'img_'.date('dmy').time().'.jpg';
				move_uploaded_file($temp_name,'../wallpaper/'.$newname);
				$result=$obj->insert('wallpapers',$wallpapertitle,$newname,$wallpaperdes);
				if($result==1)
					$msg='sucess';
					isset($_POST['submit']);
			}			
		}
		else
		{
			$msg ="Uploaded file is not image...";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
<script language="JavaScript">
	function formload()
	{
		var wallpapertitle=document.getElementById('wallpapertitle');
		wallpapertitle.focus();
	}
	function Checkform()
	{
		var wallpaper=document.getElementById('wallpaper');
		var wallpapertitle=document.getElementById('wallpapertitle');
		var wallpaperdes=document.getElementById('wallpaperdes');
		if(wallpapertitle.value=='')
		{
			alert('Enter Valid wallpaper title');
			wallpapertitle.focus();
			return false;
		}
		else if(wallpaper.value=='')
		{
			alert('Enter Valid wallpaper url');
			wallpaper.focus();
			return false;
		}
		else if(wallpaperdes.value=='')
		{
			alert('Enter Valid video description.');
			wallpaperdes.focus();
			return false;
		} 
			return true;
		}
</script>
</head>
<body onload="formload();">
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<td>
		     <form action="" method="post" enctype="multipart/form-data" name="uploadvideo">
			<table style="margin:auto:"  cellpadding="0" class="uploadtab" cellspacing="4">
	     <tr>
				<th class="headth" colspan="3">Upload Wallpapers</th>
		</tr>
		<tr>
			<?php  
				if(isset($msg))
				{
					if($msg=='sucess')
						{
				?>
				<th class="green" colspan="3">File Uploaded sucessfully</th>
				<?php 
				}
				else
				{
				?>
				<th class="red" colspan="3"><?php echo $msg; ?></th>
				<?php
				} 
					unset($msg);
				}
				?>
		</tr>
		<tr>
			<td>
				<tr>
						<th align="right">Title</th>
						<td><input type="text" class="inputtype" name="wallpapertitle" id="wallpapertitle" size="33" /></td>
					</tr>
					<tr>
						<th align="right">Image</th>
						<td><input class="inputtype" type="file" name="wallpaper" id="wallpaper" /></td>
					</tr>
					<tr>
						<th valign="top">Description</th>
						<td><textarea name="wallpaperdes" class="inputtype" id="wallpaperdes" cols="25" ></textarea> </td>
					</tr>
					<tr>
						<th></th>
						<td align="right"><input type="submit" class="uploadbtn" name="submit" id="submit" value="Upload" onclick="return Checkform();" />
						<input type="reset" class="cancelbtn" name="cancel" id="cancel" value="cancel"/> </td>
					</tr>
				</table>
				</form>				
			</td>
		</tr>
</table>
</body>
</html>
