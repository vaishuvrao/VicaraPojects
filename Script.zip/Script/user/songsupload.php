<?php
		include("session_chek.php");
		include("../include/database.php");
		include("../include/program_class.php");
		$obj=new general_class();
		if(isset($_POST['submit']) && $_POST['submit']=='Upload')
		{
			$Songstitle = $_POST['Songstitle'];
			$Songsdes = $_POST['Songsdes'];
			$ext=explode(".",$_FILES['Songs']['name']);
			$num=sizeof($ext);
			if($ext[$num-1]=="mp3" && $_FILES['Songs']['size']<=(49*1024*1024))
			{
				$name = $_FILES['Songs']['name'];
				$temp_name = $_FILES['Songs']['tmp_name'];
				$newname = 'song_'.date('dmy').time().'.mp3';
				move_uploaded_file($temp_name,'../song/'.$newname);
				$result=$obj->insert('songs',$Songstitle,$newname,$Songsdes);
					if($result==1)
					   $msg='sucess';
					   $_POST['submit']='';
			}
			else
			{
				$msg= "Song not uploaded successfully !!!!!!<br />Because It may not MP3 or Size More then 50MB";
			}
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
<script language="JavaScript">
	function formload()
	{
		var Songstitle=document.getElementById('Songstitle');
		Songstitle.focus();
	}
	function Checkform()
	{
		var Songs=document.getElementById('Songs');
		var Songstitle=document.getElementById('Songstitle');
		var Songsdes=document.getElementById('Songsdes');
		if(Songstitle.value=='')
		{
			alert('Enter Valid Songs title');
			Songstitle.focus();
			return false;
		}
		else if(Songs.value=='')
		{
			alert('Enter Valid Songs url');
			Songs.focus();
			return false;
		}
		else if(Songsdes.value=='')
		{
			alert('Enter Valid Songs description.');
			Songsdes.focus();
			return false;
		} 
			return true;
		}
</script>
</head>
<body onload="formload();">
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		    <td>
		        <form action="" method="post" enctype="multipart/form-data" name="uploadSongs">
				<table style="margin:auto:"  cellpadding="0" class="uploadtab" cellspacing="4">
		<tr>
				<th class="headth" colspan="2">Upload Music Songs</th>
		</tr>
			<tr>
			<?php  
				if(isset($msg))
				{
					if($msg=='sucess')
						{
				?>
				<th class="green" colspan="3">File Uploaded sucessfully</th>
				<?php 
				}
				else
				{
				?>
				<th class="red" colspan="3"><?php echo $msg; ?></th>
				<?php
				} 
					unset($msg);
				}
				?>
			</tr>
		<tr>
			<td>
			    <tr>
						<th align="right">Title</th>
						<td><input type="text" class="inputtype" name="Songstitle" id="Songstitle" size="33" /></td>
					</tr>
					<tr>
						<th align="right">Music Songs</th>
						<td><input class="inputtype" type="file" name="Songs" id="Songs" /></td>
					</tr>
					<tr>
						<th valign="top">Description</th>
						<td><textarea name="Songsdes" class="inputtype" id="Songsdes" cols="25" ></textarea> </td>
					</tr>
					<tr>
						<th></th>
						<td align="right"><input type="submit" class="uploadbtn" name="submit" id="submit" value="Upload" onclick="return Checkform();" />
						<input type="reset" class="cancelbtn" name="cancel" id="cancel" value="cancel"/>
					 </td>
						</td>
					   </tr>
				</table>
				</form>				
			</td>
		</tr>
</table>
</body>
</html>
