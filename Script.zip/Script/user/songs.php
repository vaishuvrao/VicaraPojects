<?php
		include("session_chek.php");
		include('../include/database.php');
		include('../include/program_class.php');
		$q='';
		$songurl='';
		$obj=new general_class();
		$sdata = $obj->select5record('songs',0,5);
		$snum=5;
		if(isset($_GET['q']))
		{
			$q=$_GET['q'];
		}
		if(isset($_POST['submit']))
		{		
			$q='';
			$searchterm=$_POST['search2'];
			$sdata = $obj->searchdata('songs',$searchterm);
			$snum=sizeof($sdata);
			if($snum>5)
			{
				$snum=5;
			}
			unset($_POST['submit']);
		}
		if(isset($_GET['song']))
		{
			$songurl = $_GET['song'];
			$desc = $_GET['des'];
			$title = $_GET['t'];
		}
		if($q!="")
		{
			$sdata = $obj->searchbyalpha('songs',$q);
			$snum=sizeof($sdata);
			if($snum>5)
			{
				$snum=5;
			}
		}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>

<link href="skin/jplayer.blue.monday.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="jquery-ui-1.7.1.custom/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="js/jquery.jplayer.min.js"></script>
<script type="text/javascript">
<!--
$(document).ready(function(){

	// Local copy of jQuery selectors, for performance.
	var jpPlayTime = $("#jplayer_play_time");
	var jpTotalTime = $("#jplayer_total_time");

	$("#jquery_jplayer").jPlayer({
		ready: function () {
			this.element.jPlayer("setFile", "http://www.miaowmusic.com/audio/ogg/Miaow-07-Bubble.mp3", "http://www.miaowmusic.com/audio/ogg/Miaow-07-Bubble.ogg").jPlayer("play");
		},
		volume: 50,
		oggSupport: true,
		preload: 'none'
	})
	.jPlayer("onProgressChange", function(loadPercent, playedPercentRelative, playedPercentAbsolute, playedTime, totalTime) {
		jpPlayTime.text($.jPlayer.convertTime(playedTime));
		jpTotalTime.text($.jPlayer.convertTime(totalTime));
	})
	.jPlayer("onSoundComplete", function() {
		this.element.jPlayer("play");
	});
});
-->
</script>
<script language="javascript" type="text/javascript">
function downlaod(linkurl)
{
	document.location.href='../include/opendoc.php?filename='+linkurl;
	return false;
}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
</head>
<body>
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr> 
		<th><font color="#CC6600"><u>Search by Alphabates</u></font> 
      <br><?php 
								$alpha = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
								for($i=0;$i<26;$i++)
								{
									echo "<a class='keysearch' href='?q=".$alpha[$i]."'>".$alpha[$i]."</a>&nbsp;&nbsp;&nbsp;";
								}
							?> 
		</th>
		<form action="" method="post">	
		<td align="right"><input type="text" name="search2" id="search" value="search songs" onFocus="if(this.value=='search songs'){this.value='';}" onBlur="if(this.value==''){this.value='search songs';}" style="padding:3px;" class="inputsr" size="35" /> 
		 <input type="submit" style="padding:3px;" name="submit" value="" id="submit" class="searchbnt"/> 
		</td></form>
  		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr>
		<td style="padding-left:60px;"><?php if(isset($title)){ echo $title; } ?></td>
		<th class="headth">SONG(S)</th>
		</tr>
		<tr>
			<?php if($songurl!=""){ ?>
			<td align="center">
				<embed type="application/x-shockwave-flash" wmode="transparent" src="http://www.google.com/reader/ui/3523697345-audio-player.swf?audioUrl=../song/<?php echo $songurl; ?>" height="27" width="320"></embed>
				<embed type="application/x-shockwave-flash" wmode="transparent" src="http://www.google.com/reader/ui/3523697345-audio-player.swf?audioUrl=../song/<?php echo $songurl; ?>" height="27" width="320"></embed>
			</td>
			<?php } 
				else
				{
					echo "<td></td>";
				}
			?>
				<td rowspan="5" style="border:0px solid #000000;" valign="top">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
			<tr>
				<?php 
				if($sdata!=0)
				{
					echo "<td valign='top'>";
					for($i=0;$i<$snum;$i++)
					{
					?>
				<table cellpadding="4" border="0" cellspacing="0" class="vidtable">
				<tr>
				<td rowspan="2" valign="top" width="100px" align="center">
				<div class="vidmin">
				  <img src="../images/images3.jpeg" width="100px" height="80px" alt="<?php echo $sdata[$i]['title']; ?>" title="<?php echo $sdata[$i]['title']; ?>" />
				</div>
				</td>
				<td valign="top" width="250px">
					<a href="Songs.php?song=<?php echo $sdata[$i]['url']; ?>&&q=<?php echo $q; ?>&&t=<?php echo $sdata[$i]['title']; ?>&&des=<?php echo $sdata[$i]['description']; ?>" class='keysearch' title="<?php echo $sdata[$i]['title']; ?>"><?php echo $sdata[$i]['title']; ?></a>
				</td>
				</tr>
				<tr>
					<td valign="top">
						<?php echo $sdata[$i]['description']; ?>
					</td>
				</tr>
				</table>
				<?php
					}
					echo "</td>";
				}
				else
				{
				?>
					<th>
						<div class="red">No Data Found in Database.</div>
					</th>
				<?php
					}
				?>
			
			</tr>
		</table>
		</tr>
		</td>
		</tr>
		<tr>
			<td height="10px"></td>
		</tr>
		<tr>
			<td style="padding-left:220px;">
			<?php if($songurl!=""){ ?>
				<input type="submit" style="padding:3px;" name="download" value="Search" id="download" class="downloadbnt" onclick="return downlaod('../song/<?php echo $songurl; ?>');" title="download video <?php echo $title; ?>"/>
			<?php } ?>
			</td>
		</tr>
		<tr>
			<td style="padding-left:20px;">
				<?php if(isset($desc)){ ?></td>
			<td><?php } ?></td>
		</tr>
</table>
</body>
</html>
