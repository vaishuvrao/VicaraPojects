<?php
		include("session_chek.php");
		include('../include/database.php');
		include('../include/program_class.php');
		$q='';
		$imgurl ='';
		$obj=new general_class();
		$wdata = $obj->select5record('wallpapers',0,6);
		$wnum=6;
		if(isset($_GET['q']))
		{
			$q=$_GET['q'];
		}
		if(isset($q))
		{
			$wdata = $obj->searchbyalpha('wallpapers',$q);
			$wnum=sizeof($wdata);
			if($wnum>6)
			{
				$wnum=6;
			}
		}
		if(isset($_POST['submit']))
		{		
			$q='';
			$searchterm=$_POST['search2'];
			$wdata = $obj->searchdata('wallpapers',$searchterm);
			$wnum=sizeof($wdata);
			if($wnum>6)
			{
				$wnum=6;
			}
			unset($_POST['submit']);
		}
		if(isset($_GET['img']))
		{
			$imgurl = $_GET['img'];
			$desc = $_GET['desc'];
			$title = $_GET['t'];
		}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<script language="javascript" type="text/javascript">
function downlaod(linkurl)
{
	alert('For Image Download follow the following Steps :\n\n               1:   Right click on Image\n\n               2:   click on Save image AS ..\n\n               3:   save your image.\n\nThanking you for using MYTUBE');
	return false;
}
</script>
</html>
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
</head>
<body>
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr> 
		
    <th> <font color="#CC6600"><u>Search by Alphabates</u></font> 
      <br>		<?php 
								$alpha = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
								for($i=0;$i<26;$i++)
								{
									echo "<a class='keysearch' href='?q=".$alpha[$i]."'>".$alpha[$i]."</a>&nbsp;&nbsp;&nbsp;";
								}
							?>
		</th>
		<form action="" method="post">	
		<td align="right"><input type="text" name="search2" id="search" value="search wallpaper" onFocus="if(this.value=='search wallpaper'){this.value='';}" onBlur="if(this.value==''){this.value='search wallpaper';}" style="padding:3px;" class="inputsr" size="30" /> 
		 <input type="submit" style="padding:3px;" name="submit" value="" id="submit" class="searchbnt"/> 
		</td></form>
  		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr>
		<td style="padding-left:60px;"><?php if(isset($title)){ echo $title; } ?></td>
		<th class="headth">WALLPAPER(S)</th>
		</tr>
		<tr>
			<td align="center">
			<?php 	
					if($imgurl!="")
					{
				?>
				<div style="-moz-box-shadow:0px 0px 0px 0px #000000; padding:10px; -moz-border-radius:0px; margin:5px; float:center; "><img src="../wallpaper/<?php echo $imgurl; ?>" title="<?php echo $wdata[$i]['title']; ?>" alt="<?php echo $wdata[$i]['title']; ?>" border="0"/></div>
				<?php
					}
				?>
			</td>
			<th  width="33%" valign="top" style="padding-left:20px;">
						<?php
							if($wdata!=0)
							{
							for($i=0;$i<$wnum;$i++)
							{
							 ?>
						<div style="border:1px solid #000000; width:130px; -moz-border-radius:7px; -moz-box-shadow:0px 0px 5px 0px #000000; margin:5px; float:left; height:102px;"><a href="wallpapers.php?img=<?php echo $wdata[$i]['url']; ?>&&q=<?php echo $q; ?>&&t=<?php echo $wdata[$i]['title']; ?>&&desc=<?php echo $wdata[$i]['description']; ?>"><img src="../wallpaper/<?php echo $wdata[$i]['url']; ?>" title="<?php echo $wdata[$i]['title']; ?>" alt="<?php echo $wdata[$i]['title']; ?>" width="120px" height="100px" border="0"/></div>
						<?php
					}
					echo "</td>";
				}
				else
				{
				?>
								<div class="red">No Data Found in Database.</div>
				<?php
					}
				?>
						</th>
		</tr>
		<tr>	<?php if(isset($desc)){ ?>
				<td style="padding-left:220px;">
				<input type="submit" style="padding:3px;" name="download" value="Search" id="download" class="downloadbnt" onclick="return downlaod('../wallpapers/<?php echo $imgurl; ?>');" title="download wallpapers <?php echo $title; ?>"/>
			</td>
				<?php } ?>
		</tr>
		<tr>
			<td></td>
			<td></td>
		</tr>
</table>
</body>
</html>
