<?php
	include("session_chek.php");
	include("../include/database.php");
	include("../include/register_class.php");
	$id=$_SESSION['userid'];
	if(isset($_SESSION['password']))
	{
		$passres=$_SESSION['password'];
	}
	$obj=new general();
	$msg='';
	if(isset($_POST['submit']) && $_POST['submit']=='submit')
	{
		$password = $_POST['oldpass'];
		$npassword=$_POST['newpass'];
		$result=$obj->updatepassword($npassword,$id,$password);
		if($result==1)
		{
			$msg='Password updated sucessfully.';
		}		
		else
		{
			$msg='Old Password not match to Username.';
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
<script language="JavaScript">
	function formload()
	{
		var oldpass=document.getElementById('oldpass');
		oldpass.focus();
	}
	function Checkform()
	{
		var oldpass=document.getElementById('oldpass');
		var newpass=document.getElementById('newpass');
		var cnewpass=document.getElementById('cnewpass');
		if(oldpass.value=='')
		{
			alert('Enter Valid old password.');
			oldpass.focus();
			return false;
		}
		else if(newpass.value=='')
		{
			alert('Enter Valid new password.');
			newpass.focus();
			return false;
		}
		else if(cnewpass.value=='')
		{
			alert('Enter Valid confirm new password.');
			oldpass.focus();
			return false;
		}
		else if(newpass.value!=cnewpass.value)
		{
			alert('Confirm password does not match to new password.');
			newpass.value='';
			cnewpass.value='';
			newpass.focus();
			return false;		
		}
         return true;
		}
</script>
</head>
<body onload="formload();">
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<tr>
		<th id='error'><?php echo $msg; ?></th>
		</tr>
		<td>
		        <form action="" method="post" name="changepassword">
				<table style="margin:auto:"  cellpadding="0" class="uploadtab" cellspacing="4">	
		<tr>
				<th class="headth" colspan="3">Get New Password</th>
		</tr>
		<tr>
			<td>
				<?php if(isset($passres)){ ?>
						<input type="hidden" name="oldpass" value="<?php echo $passres; ?>" id="oldpass"/>
				<?php } else { ?>
					<tr>
						<th align="right">Old Password</th>
						<td><input type="password" class="inputtype" name="oldpass" id="oldpass"/></td>
					</tr>				
				<?php } ?>
					<tr>
						<th align="right">New Password</th>
						<td><input type="password" class="inputtype" name="newpass" id="newpass"/></td>
					</tr>
					<tr>
						<th align="right">Confirm Password</th>
						<td><input type="password" class="inputtype" name="cnewpass" id="cnewpass"/></td>
					</tr>
					<tr>
						<th></th>
						<td align="right"><input class="submitbtn" type="submit" name="submit" id="submit" value="submit" onclick="return Checkform();"/>
								<input type="reset" class="cancelbtn" name="reset" id="reset" value="Cancel" />
						 </td>
					</tr>
				</table>
				</form>				
			</td>
		</tr>
</table>
</body>
</html>
