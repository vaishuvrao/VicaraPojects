<?php
	include("session_chek.php");
	include("../include/database.php");
	include("../include/program_class.php");
	$obj=new general_class();
	if(isset($_POST['submit']) && $_POST['submit']=='Upload')
	{
		$videotitle = $_POST['videotitle'];
		$videodes = $_POST['videodes'];
		$ext=explode(".",$_FILES['videourl']['name']);
		if($ext[1]=="flv" && $_FILES['videourl']['size']<=(49*1024*1024))
		{
			$name = $_FILES['videourl']['name'];
			$temp_name = $_FILES['videourl']['tmp_name'];
			$newname = 'vid'.date('dmy').time();
			 move_uploaded_file($temp_name,'../video/'.$newname.'.flv');
				$result=$obj->insert('video',$videotitle,$newname,$videodes);
					if($result==1)
					   $msg='sucess';
					   unset($_POST['submit']); 
		}
		else
		{
			$msg= "viedo not uploaded successfully !!!!!!<br />Because It may not FLV or Size More then 50MB";
		}
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
<script language="JavaScript">
	function formload()
	{
		var videotitle=document.getElementById('videotitle');
		videotitle.focus();
	}
	function Checkform()
	{
		var video=document.getElementById('video');
		var videotitle=document.getElementById('videotitle');
		var videodes=document.getElementById('videodes');
		if(videotitle.value=='')
		{
			alert('Enter Valid video title');
			videotitle.focus();
			return false;
		}
		else if(video.value=='')
		{
			alert('Enter Valid video url');
			video.focus();
			return false;
		}
		else if(videodes.value=='')
		{
			alert('Enter Valid video description.');
			videodes.focus();
			return false;
		} 
			return true;
		}
</script>
</head>
<body onload="formload();">
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<td>
             <form action="" method="post" enctype="multipart/form-data" name="uploadvideo">
			<table style="margin:auto:"  cellpadding="0" class="uploadtab" cellspacing="4">
			<tr>
				<th class="headth" colspan="3">Upload Video</th>
			</tr>
			<tr>
			<?php  
				if(isset($msg))
				{
					if($msg=='sucess')
						{
				?>
				<th class="green" colspan="3">File Uploaded sucessfully</th>
				<?php 
				}
				else
				{
				?>
				<th class="red" colspan="3"><?php echo $msg; ?></th>
				<?php
				} 
					unset($msg);
				}
				?>
			</tr>
		<tr>
			<td>
			     	<tr>
						<th>Title</th>
						<td><input type="text" class="inputtype" name="videotitle" id="videotitle" size="33"/></td>
					</tr>
					<tr>
					   <th>Video</th>
						<td><input class="inputtype" type="file" name="videourl" id="video"/></td>
					</tr>
					<tr>
						<th valign="top">Description</th>
						<td><textarea name="videodes" class="inputtype" id="videodes" cols="25" ></textarea> </td>
					</tr>
					<tr>
						<th></th> 
						<td align="right"><input type="submit" class="uploadbtn" name="submit" id="submit" value="Upload" onclick="return Checkform();"/>
						<input type="reset" class="cancelbtn" name="cancel" id="cancel" value="cancel"/> </td>
					</tr>
				</table>
				</form>				
			 </tr>
			 </table>
</body>
</html>
