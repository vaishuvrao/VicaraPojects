<?php
	session_start();
	if($_SESSION['username']!="")
	{
		session_destroy();
?>
		<script language='javascript'>
			document.location.href='../'; 
			alert('You logout Successfully..'); 
		</script>
<?php
	header('location:../');
	}
?>