<?php
	include("session_chek.php");
	include("../include/database.php");
	include("../include/register_class.php");
	$id=$_SESSION['userid'];
	$obj=new general();
	$msg='';
	if(isset($_POST['submit'])&& $_POST['submit']=='submit')
	{
		$firstname=$_POST['firstname'];
		$lastname = $_POST['lastname'];
		$gender=$_POST['gender'];
		$birthdate=$_POST['day']."-".$_POST['month']."-".$_POST['year'];
		$email=$_POST['email'];
		$country=$_POST['country'];
		$postalcode=$_POST['postalcode'];
		$sec_ques=$_POST['sec_ques'];
		$sec_ans=$_POST['sec_ans'];
		$obj->update($id,$firstname,$lastname,$gender,$birthdate,$email,$country,$postalcode,$sec_ques,$sec_ans);
		$msg="Profile updated sucessfully..";
	}
	$row=array();
	$row[]=$obj->selwithid($id);
	$date=array();
	$date=explode("-",$row[0]['birthdate']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script language="javascript" type="text/javascript">
	function isvalidform()
	{
		for(var i=1;i<=12;i++)
		{
			var form = document.getElementById(i);
			if(form.value=="")
			{
				alert("Fill all field of the register form.");
				form.focus();
				return false;
			}
		}
		return true;
	}
function daycheck()
{
		var day = document.getElementById(4);
		var month = document.getElementById('month');
		var year = document.getElementById('year');
		if(day.value==31)
		{
			if(month.value==4||month.value==6||month.value==9||month.value==11)
			{
				alert('This month have not more than 30 days');
				return false;
			}
			else if(month.value==2)
			{
				alert('This month have not more than 28 or 29 days');
				return false;
			}
			return true;			
		}
		else if(day.value==30)
		{
			if(month.value==2)
			{
				alert('This month have not more than 28 or 29 days');
				return false;
			}
			return true;			
		}
		else if(day.value==29)
		{
			if((year.value)%4!=0)
			{
				alert('This month have not more than 28 days');
				return false;
			}
			return true;			
		}
}
function formload()
{
	var name = document.getElementById('1');
	name.focus();
}

</script>
<title><?php echo $_SESSION['username'] ?> :: View and Uplaod Video</title>
</head>
<body>
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<th id="error"><?php echo $msg; ?></th>
		</tr>
		<tr>
			<TD align="center">
	           <form action="" method="post" name="frmregiser">
						<table cellspacing="0" cellpadding="3" >
							<tr>
								<td colspan="4" style="background:#B76004; -moz-border-radius:10px; -moz-box-shadow:0px 0px 5px 0px #000000; 		color:#000000;
		padding:5px; text-shadow:1px 1px 1px #FFFFFF; font-size:20px" align="center"><b>Your Profile</b></td>
							</tr>
							<tr>
							<td height="10px"></td>
							</tr>
							<tr>
								<td colspan="4" class="headth" style="color:#000000; font-weight:bold; padding-left:10px;">1. About you</td>
							</tr>
							<tr>
								<td height="10px">
								</td>
							</tr>
							<tr>
								<td width="80px"></td>
								<td>first Name</td>
								<td><input type="text" name="firstname" id="1" tabindex="1" class="inputtype" size="30" value="<?php echo $row[0]['firstname']; ?>"/></td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>Last Name</td>
								<td><input type="text" name="lastname" id="2" tabindex="2" class="inputtype" size="30" value="<?php echo $row[0]['lastname']; ?>" /></td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>I am</td>
								<td><select id="3" tabindex="3" class="inputtype" name="gender">
										<option value="">- - - - - Select gender - - - - -</option>
										<option value="Male" <?php if($row[0]['gender']=='Male'){ ?> selected="selected" <?php } ?>>Male</option>
										<option value="Female" <?php if($row[0]['gender']=='Female'){ ?> selected="selected" <?php } ?>>Female</option>
									</select>
								</td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>Birthday</td>
								<td><select id="4" tabindex="4" class="inputtype" name="day">
										<option value="" selected="selected">- Day -</option>
										<?php 
											for($i=1;$i<=31;$i++)
											{
										?>
										<option onclick="return  daycheck();" value="<?php echo $i; ?>" <?php if($date[0]==$i){ ?> selected="selected" <?php } ?>><?php echo $i; ?></option>
										<?php
										}
										?>
									</select>
									<select id="month" tabindex="5" class="inputtype" name="month">
										<option value="" selected="selected">- Month -</option>
										<?php 
											for($i=1;$i<=12;$i++)
											{
										?>
										<option onclick="return  daycheck();" value="<?php echo $i; ?>" <?php if($date[1]==$i){ ?> selected="selected" <?php } ?>><?php echo $i; ?></option>
										<?php
										}
										?>
									</select>
									<select id="year" tabindex="6" class="inputtype" name="year">
										<option value="" selected="selected">- Year -</option>
										<?php 
											for($i=date("Y")-100;$i<=date("Y")-10;$i++)
											{
										?>
											<option value="<?php echo $i; ?>" <?php if($date[2]==$i){ ?> selected="selected" <?php } ?>><?php echo $i; ?></option>
										<?php
										}
										?>
									</select>
									</td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>E-Mail</td>
								<td><input type="text" name="email" id="5" tabindex="7" class="inputtype" size="30" value="<?php echo $row[0]['email']; ?>"/></td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>Country</td>
								<td><select id="6" tabindex="8" class="inputtype" name="country">
										<option value="" selected="selected">- - - - - Select Country - - - - -</option>
										<option <?php if($row[0]['country']=='America'){ ?> selected="selected" <?php } ?> value="America">America</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Australia</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Algeria</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Belgium</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Canada</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>China</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Dubai</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Egypt</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>England</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Finland</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Holland</option>
										<option <?php if($row[0]['country']=='India'){ ?> selected="selected" <?php } ?> value="India">India</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Istanbul</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Jakarta</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Japan</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Malaysia</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>New Zealand</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Portland</option>
										<option <?php if($row[0]['country']=='Australia'){ ?> selected="selected" <?php } ?>>Other</option>
									</select>
								</td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>Postal Code</td>
								<td><input type="text" name="postalcode" id="7" tabindex="9" class="inputtype" size="30" value="<?php echo $row[0]['postalcode']; ?>" /></td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td height="10px">
								</td>
							</tr>
							<tr>
								<td height="10px">
								</td>
							</tr>
							<tr>
								<td colspan="4" class="headth" style="color:#000000; font-weight:bold; padding-left:10px;">2. In case you forgot your password</td>
							</tr>
							<tr>
								<td height="10px">
								</td>
							</tr>
							<tr>
								<td></td>
								<td>Security Question</td>
								<td>
								<select name="sec_ques" class="inputtype" tabindex="10">
											<option selected="selected" value="">- Select Security question -</option>
											<option value="Where did you meet your spouse?">Where did you meet 
											your spouse?</option>
											<option <?php if($row[0]['sec_ques']=="What was the name of your first school?"){?> selected="selected" <?php } ?>>What was the 
											name of your first school?</option>
											<option value="Who was your childhood hero?">Who was your childhood 
											hero?</option>
											<option value="What is your favorite passtime?">What is your favorite 
											passtime?</option>
											<option value="Which is your favorite sports team?">What is your favorite 
											sports team?</option>
											<option value="What is your father middle name?">What is your father's 
											middle name?</option>
											<option value="What was your high school mascot?">What was your high 
											school mascot?</option>
											<option value="What make was your first car or bike?">What make was 
											your first car or bike?</option>
          						</select>
								</td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td></td>
								<td>Security Answer</td>
								<td><input type="text" name="sec_ans" id="12" tabindex="11" class="inputtype" size="30" value="<?php echo $row[0]['sec_ans']; ?>"/></td>
								<td id="compalsory">*</td>
							</tr>
							<tr>
								<td height="15px">
								</td>
							</tr>
							<tr>
								<td></td>
								<td colspan="2" align="center"><input type="submit" name="submit" value="submit" id="submit" onclick="return isvalidform();" class="submitbtn" />&nbsp;
								<input type="reset" name="reset" value="Cancel" id="reset" class="cancelbtn" /></td>
							</tr>
						</table>
						</form>
					</td>
					</tr>
				</table> 
			</TD>
		</tr>
</table>
</body>
</html>
