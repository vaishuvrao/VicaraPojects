<?php
		include("../include/database.php");
		include("../include/program_class.php");
		include("session_chek.php");
		$q='';
		$vidurl='';
		$obj=new general_class();
		$vdata = $obj->select5record('video',0,3);
		$vnum=3;
		if(isset($_POST['submit']))
		{
			$searchkey=$_POST['search2'];
			$vdata=$obj->searchdata('video',$searchkey);
			$vnum=sizeof($vdata);
			if($vnum>3)
			{
				$vnum=3;
			}
		}
		else if(isset($_GET['q']))
		{
			$q=$_GET['q'];
			$vdata = $obj->searchbyalpha('video',$q);
			$vnum=sizeof($vdata);
			if($vnum>3)
			{
				$vnum=3;
			}
		}

		if(isset($_GET['video']))
		{
			$vidurl = $_GET['video'];
			$desc = $_GET['des'];
			$title = $_GET['t'];
		}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?>:: View and Uplaod Video</title>
<script type="text/javascript">
function MM_CheckFlashVersion(reqVerStr,msg){
  with(navigator){
    var isIE  = (appVersion.indexOf("MSIE") != -1 && userAgent.indexOf("Opera") == -1);
    var isWin = (appVersion.toLowerCase().indexOf("win") != -1);
    if (!isIE || !isWin){  
      var flashVer = -1;
      if (plugins && plugins.length > 0){
        var desc = plugins["Shockwave Flash"] ? plugins["Shockwave Flash"].description : "";
        desc = plugins["Shockwave Flash 2.0"] ? plugins["Shockwave Flash 2.0"].description : desc;
        if (desc == "") flashVer = -1;
        else{
          var descArr = desc.split(" ");
          var tempArrMajor = descArr[2].split(".");
          var verMajor = tempArrMajor[0];
          var tempArrMinor = (descArr[3] != "") ? descArr[3].split("r") : descArr[4].split("r");
          var verMinor = (tempArrMinor[1] > 0) ? tempArrMinor[1] : 0;
          flashVer =  parseFloat(verMajor + "." + verMinor);
        }
      }
      // WebTV has Flash Player 4 or lower -- too low for video
      else if (userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 4.0;

      var verArr = reqVerStr.split(",");
      var reqVer = parseFloat(verArr[0] + "." + verArr[2]);
  
      if (flashVer < reqVer){
        if (confirm(msg))
          window.location = "http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash";
      }
    }
  } 
}
function downlaod(linkurl)
{
	document.location.href='../include/opendoc.php?filename='+linkurl;
	return false;
}
</script>
</head>
<body onload="MM_CheckFlashVersion('7,0,0,0','Content on this page requires a newer version of Macromedia Flash Player. Do you want to download it now?');">
<table cellpadding="0" border="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr> 
		<th><font color="#CC6600"><u>Search by Alphabates</u></font> 
      <br><?php 
								$alpha = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
								for($i=0;$i<26;$i++)
								{
									echo "<a class='keysearch' href='?q=".$alpha[$i]."'>".$alpha[$i]."</a>&nbsp;&nbsp;&nbsp;";
								}
							?> 
		</th>
		<form action="" method="post">	
		<td width="44%" align="right"><input type="text" name="search2" id="search" value="search video" onFocus="if(this.value=='search video'){this.value='';}" onBlur="if(this.value==''){this.value='search video';}" style="padding:3px;" class="inputsr" size="35" /> 
		 <input type="submit" style="padding:3px;" name="submit" value="" id="submit" class="searchbnt"/> 
		</td>
		</form>
  		</tr>
		<tr>
		<td height="20px"></td>
		</tr>
		<tr>
		<td style="padding-left:60px;"><?php if(isset($title)){ echo $title; } ?></td>
		<th class="headth">VIDEO(S)</th>
		</tr>
		<tr>
			<td height="420" align="left" style="padding-left:60px;">
			 <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="422" height="411" id="FLVPlayer">
                  <param name="movie" value="FLVPlayer_Progressive.swf" />
                  <param name="salign" value="lt" />
                  <param name="quality" value="high" />
                  <param name="scale" value="noscale" />
                  <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=../video/<?php echo $vidurl; ?>&autoPlay=false&autoRewind=true" />
                  <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=../video/<?php echo $vidurl; ?>&autoPlay=false&autoRewind=true" quality="high" scale="noscale" width="422" height="411" name="FLVPlayer" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />                  
</object>	
		</td>
		<td rowspan="3" style="border:0px solid #000000;" valign="top">
			<table cellpadding="0" cellspacing="0" border="0" width="100%">
			<tr>
				<?php 
				if($vdata!=0)
				{
					echo "<td valign='top'>";
					for($i=0;$i<$vnum;$i++)
					{
					?>
				<table cellpadding="4" border="0" cellspacing="0" class="vidtable">
				<tr>
				<td rowspan="2" valign="top">
				<div class="vidmin">
				  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="120" height="120" id="FLVPlayer1">
                      <param name="movie" value="FLVPlayer_Progressive.swf" />
                      <param name="salign" value="lt" />
                      <param name="quality" value="high" />
                      <param name="scale" value="noscale" />
                      <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Clear_Skin_1&streamName=../video/<?php echo $vdata[$i]['url']; ?>&autoPlay=false&autoRewind=false" />
                      <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Clear_Skin_1&streamName=../video/<?php echo $vdata[$i]['url']; ?>&autoPlay=false&autoRewind=false" quality="high" scale="noscale" width="120" height="120" name="FLVPlayer1" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />                    
</object>
				</div>
				</td>
				<td valign="top">
					<a href="video.php?video=<?php echo $vdata[$i]['url']; ?>&&q=<?php echo $q; ?>&&t=<?php echo $vdata[$i]['title']; ?>&&des=<?php echo $vdata[$i]['description']; ?>" class='keysearch' title="<?php echo $vdata[$i]['title']; ?>"><?php echo $vdata[$i]['title']; ?></a>
				</td>
				</tr>
				<tr>
					<td valign="top">
						<?php echo $vdata[$i]['description']; ?>
					</td>
				</tr>
				</table>
				<?php
					}
					echo "</td>";
				}
				else
				{
				?>
					<th>
						<div class="red">No Data Found in Database.</div>
					</th>
				<?php
					}
				?>
			
			</tr>
		</table>
		</td>
		</tr>
		<tr>
			<td style="padding-left:220px;">
			<?php if(isset($desc)){ ?>
				<input type="submit" style="padding:3px;" name="download" value="Search" id="download" class="downloadbnt" onclick="return downlaod('../video/<?php echo $vidurl; ?>.flv');" title="download video <?php echo $title; ?>"/>
			<?php } ?>
			</td>
		</tr>
		<tr>
			<td style="padding-left:20px;">
				<?php if(isset($desc)){echo $desc;} ?>
			</td>
		</tr>
</table>
</body>
</html>
