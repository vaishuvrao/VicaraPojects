<?php
	session_start();
	include('../include/database.php');
	include('../include/program_class.php');
	$obj=new general_class();
	$rows=array();
	$rows=$obj->select5record('video',0,5);
	$num=sizeof($rows);
	$wrows=$obj->select5record('wallpapers',0,10);
	$wnum=sizeof($wrows);
	$sdata = $obj->select5record('songs',0,5);
	$snum=sizeof($sdata);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
	include("../include/cssnjs.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $_SESSION['username'] ?> :: home page.</title>
</head>
<body>
<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("../include/loginhead.php"); ?></td>
		</tr>
		<tr>
			<td colspan="2"><?php include("usermenu/index.php"); ?></td>
		</tr>	
		<tr>
			<td align="center">
				<table border="0" width="99%">
					<tr>
						<th class="headth" width="33%">Video</th>
						<th class="headth" width="33%">Wallpapers</th>
						<th class="headth" width="33%">Songs</th>
					</tr>
					<tr>
						<th width="33%" align="left" valign="top">
							<?php
								if(isset($num) && $num!="")
								{ 
								for($i=0;$i<$num;$i++)
									{
							 ?>
							 	<table cellpadding="4" cellspacing="0" class="vidtable" >
								<tr>
									<td rowspan="2" valign="top">
										<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="100" height="100" id="FLVPlayer">
                                          <param name="movie" value="FLVPlayer_Progressive.swf" />
                                          <param name="salign" value="lt" />
                                          <param name="quality" value="high" />
                                          <param name="scale" value="noscale" />
                                          <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Corona_Skin_1&streamName=../video/<?php echo $rows[$i]['url']; ?>&autoPlay=false&autoRewind=true" />
                                          <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Corona_Skin_1&streamName=../video/<?php echo $rows[$i]['url']; ?>&autoPlay=false&autoRewind=true" quality="high" scale="noscale" width="100" height="100" name="FLVPlayer" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />                                        
</object>									</td>
									<td valign="top" height="35px" style="border-bottom:1px solid #000000;">
										<a href="video.php?video=<?php echo $rows[$i]['url']; ?>&&t=<?php echo $rows[$i]['title']; ?>&&des=<?php echo $rows[$i]['description']; ?>" class='keysearch' title="<?php echo $rows[$i]['title']; ?>"><?php echo $rows[$i]['title']; ?><?php echo $rows[$i]['title']; ?></a>
									</td>
								</tr>
								<tr>
									<td style="font-size:10px;" valign="top" align="justify">
										<?php echo $rows[$i]['description']; ?>
									</td>
								</tr>
								</table>
							<?php
							}
							}
							else
							{
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
						<th  width="33%" valign="top" style="padding-left:20px;">
						<?php 
							if(isset($wnum) && $wnum!="")
								{
							for($i=0;$i<$wnum;$i++)
									{
							 ?>
						<div style="border:1px solid #000000; width:130px; -moz-border-radius:7px; -moz-box-shadow:0px 0px 5px 0px #000000; margin:5px; float:left; height:102px;"><a href="wallpapers.php?img=<?php echo $wrows[$i]['url']; ?>&&t=<?php echo $wrows[$i]['title']; ?>&&desc=<?php echo $wrows[$i]['description']; ?>"><img src="../wallpaper/<?php echo $wrows[$i]['url']; ?>" title="<?php echo $wrows[$i]['title']; ?>" alt="<?php echo $wrows[$i]['title']; ?>" width="120px" height="100px" border="0"/></div>
						<?php
							}
							}
							else
							{
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
						<th valign="top">
						<?php 
							if(isset($sdata) && $sdata!="")
							{
							for($i=0;$i<$snum;$i++)
									{
							 ?>
						 <table class="vidtable1" cellpadding="5" cellspacing="0">
							 <tr>
							 <td width="80px" rowspan="2">
							 <img src="../images/images3.jpeg" width="80px" height="80px" alt="<?php echo $sdata[$i]['title']; ?>" title="<?php echo $sdata[$i]['title']; ?>" />
							 </td>
							 <td valign="top" height="35px" style="border-bottom:1px solid #000000;" align="left">
										<a href="songs.php?songs=<?php echo $sdata[$i]['url']; ?>" class='keysearch' title="<?php echo $sdata[$i]['title']; ?>"><?php echo $sdata[$i]['title']; ?></a>
									</td>
							</tr>
							<tr>
							<td style="font-size:10px;" valign="top" width="250" align="justify">
										<?php echo $sdata[$i]['description']; ?>
									</td>
							</tr>
							</table>
						<?php
							}
							}
							else
							{
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
