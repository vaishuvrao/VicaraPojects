<?php
	include('include/database.php');
	include('include/program_class.php');
	$obj=new general_class();
	$rows=array();
	$rows=$obj->select5record('video',0,5);
	$num=sizeof($rows);
	$wrows=$obj->select5record('wallpapers',0,10);
	$wnum=sizeof($wrows);
	$sdata = $obj->select5record('songs',0,5);
	$snum=sizeof($sdata);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: watch and upload your favourite video.</title>
<script language="javascript">
function printPage() { print(document); }
	function validform()
	{
		var username = document.getElementById('username');
		var password = document.getElementById('password');
		if(username.value=="")
		{
			alert('Enter valid user name.');
			username.focus();
			return false;
		}
		if(password.value=="")
		{
			alert('Enter valid Password.');
			password.focus();
			return false;
		}
		return true;
	}


function MM_CheckFlashVersion(reqVerStr,msg){
  with(navigator){
    var isIE  = (appVersion.indexOf("MSIE") != -1 && userAgent.indexOf("Opera") == -1);
    var isWin = (appVersion.toLowerCase().indexOf("win") != -1);
    if (!isIE || !isWin){  
      var flashVer = -1;
      if (plugins && plugins.length > 0){
        var desc = plugins["Shockwave Flash"] ? plugins["Shockwave Flash"].description : "";
        desc = plugins["Shockwave Flash 2.0"] ? plugins["Shockwave Flash 2.0"].description : desc;
        if (desc == "") flashVer = -1;
        else{
          var descArr = desc.split(" ");
          var tempArrMajor = descArr[2].split(".");
          var verMajor = tempArrMajor[0];
          var tempArrMinor = (descArr[3] != "") ? descArr[3].split("r") : descArr[4].split("r");
          var verMinor = (tempArrMinor[1] > 0) ? tempArrMinor[1] : 0;
          flashVer =  parseFloat(verMajor + "." + verMinor);
        }
      }
      // WebTV has Flash Player 4 or lower -- too low for video
      else if (userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 4.0;

      var verArr = reqVerStr.split(",");
      var reqVer = parseFloat(verArr[0] + "." + verArr[2]);
  
      if (flashVer < reqVer){
        if (confirm(msg))
          window.location = "http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash";
      }
    }
  } 
}
</script>
<script language="JavaScript">
// Example:
// var b = new BrowserInfo();
// alert(b.version); 
function BrowserInfo()
{
  this.name = navigator.appName;
  if(name=='Microsoft Internet Explorer'){ alert('for best view use mozila'); };
  this.codename = navigator.appCodeName;
  this.version = navigator.appVersion.substring(0,4);
  this.platform = navigator.platform;
  this.javaEnabled = navigator.javaEnabled();
  this.screenWidth = screen.width;
  this.screenHeight = screen.height;
}
</script>
</head>
<body onload="BrowserInfo();;MM_CheckFlashVersion('7,0,0,0','Content on this page requires a newer version of Macromedia Flash Player. Do you want to download it now?');">
	<table cellpadding="0" class="indextab" cellspacing="0" >
		<tr>
			<td colspan="2"><?php include("include/head.php"); ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
		<form action="" method="post" name="search">
		<td align="center">	
			<table>
				<tr>
					<td></td>
					<td colspan="2" align="center" style="font-weight:bold; text-decoration:underline;">Search by Alphabates</td>
					<td></td>
				</tr>
					<tr>
						<th colspan="4">
							<?php 
								$alpha = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
								for($i=0;$i<26;$i++)
								{
									echo "<a class='keysearch' href='search.php?q=".$alpha[$i]."'>".$alpha[$i]."</a>&nbsp;&nbsp;&nbsp;";
								}
							?>
						</th>
					</tr>
				</table>
			</td>
		</form>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table border="0" width="99%">
					<tr>
						<th class="headth" width="33%">Video</th>
						<th class="headth" width="33%">Wallpapers</th>
						<th class="headth" width="33%">Songs</th>
					</tr>
					<tr>
						<th width="33%" align="left" valign="top">
							<?php 
								if(isset($num) && $num!="")
								{
							   for($i=0;$i<$num;$i++)
									{
							 ?>
							 	<table cellpadding="4" cellspacing="0" class="vidtable" >
								<tr>
									<td rowspan="2" valign="top">
									  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="100" height="100" id="FLVPlayer">
                                        <param name="movie" value="FLVPlayer_Progressive.swf" />
                                        <param name="salign" value="lt" />
                                        <param name="quality" value="high" />
                                        <param name="scale" value="noscale" />
                                        <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Clear_Skin_1&streamName=video/<?php echo $rows[$i]['url']; ?>&autoPlay=false&autoRewind=false" />
                                        <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Clear_Skin_1&streamName=video/<?php echo $rows[$i]['url']; ?>&autoPlay=false&autoRewind=false" quality="high" scale="noscale" width="100" height="100" name="FLVPlayer" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />                                      
</object>									</td>
									<td valign="top" height="35px" style="border-bottom:1px solid #000000;">
										<a href="view.php?video=<?php echo $rows[$i]['url']; ?>" class='keysearch' title="<?php echo $rows[$i]['title']; ?>"><?php echo $rows[$i]['title']; ?></a>
									</td>
								</tr>
								<tr>
									<td style="font-size:10px;" valign="top" align="justify">
										<?php echo $rows[$i]['description']; ?>
									</td>
								</tr>
								</table>
								<?php
								}
								}
								else
								{
							?>
								<div class="red">No Data Found in Database.</div>
							<?php
								}
							?>

						</th>
						<th  width="33%" valign="top" style="padding-left:20px;">
						<?php 
							if(isset($wnum) && $wnum!="")
								{
						for($i=0;$i<$wnum;$i++)
									{
							 ?>
						<div style="border:1px solid #000000; width:130px; -moz-border-radius:7px; -moz-box-shadow:0px 0px 5px 0px #000000; margin:5px; float:left; height:102px;"><img src="wallpaper/<?php echo $wrows[$i]['url']; ?>" title="<?php echo $wrows[$i]['title']; ?>" alt="<?php echo $wrows[$i]['title']; ?>" width="120px" height="100px" border="0"/></div>
<?php
								}
								}
								else
								{
							?>
								<div class="red">No Data Found in Database.</div>
							<?php
								}
							?>
						</th>
						<th  width="33%" valign="top" >
						<?php 
							if(isset($sdata) && $sdata!="")
							{
							for($i=0;$i<$snum;$i++)
									{
							 ?>
						 <table class="vidtable1" cellpadding="5" cellspacing="0">
							 <tr>
							 <td width="80px" rowspan="2">
							 <img src="images/images3.jpeg" width="80px" height="80px" alt="<?php echo $sdata[$i]['title']; ?>" title="<?php echo $sdata[$i]['title']; ?>" />
							 </td>
							 <td valign="top" height="35px" align="left" style="border-bottom:1px solid #000000;">
										<a href="view.php?songs=<?php echo $sdata[$i]['url']; ?>&&<?php if(isset($searchkey)){ ?>skey=<?php echo $searchkey; ?>&&sterm=<?php echo $searchterm; ?><?php } else if(isset($q)) { ?>q=<?php echo $q; } ?>" class='keysearch'" title="<?php echo $sdata[$i]['title']; ?>"><?php echo $sdata[$i]['title']; ?></a>
									</td>
							</tr>
							<tr>
							<td style="font-size:10px;" width="250px" valign="top" align="justify">
										<?php echo $sdata[$i]['description']; ?>
									</td>
							</tr>
							</table>
						<?php
							}
							}
							else
							{
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>

