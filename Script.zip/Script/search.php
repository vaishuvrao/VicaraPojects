<?php
		include("include/database.php");
		include("include/program_class.php");
		$q='';
		$obj=new general_class();
		$vdata=$obj->select5record('video',0,5);
		$vnum=sizeof($vdata);
		$wdata=$obj->select5record('wallpapers',0,10);
		$wnum=sizeof($wdata);
		$sdata = $obj->select5record('songs',0,5);
		$snum=sizeof($sdata);

		if(isset($_POST['submit']) || isset($_GET['skey']))
		{
			if(isset($_POST['submit']))
			{
				$searchkey = $_POST['search'];
				$searchterm = $_POST['searchterm'];
			}
			if(isset($_GET['skey']))
			{
				$searchkey=$_GET['skey'];
				$searchterm=$_GET['sterm'];
			}
			if($searchkey!='all')
			{
				
				if($searchkey=='video')
				{
					$vdata = $obj->searchdata($searchkey,$searchterm);
					$vnum=sizeof($vdata);
				}
				if($searchkey=='wallpapers')
				{
					$wdata = $obj->searchdata($searchkey,$searchterm);
					$wnum=sizeof($wdata);
				}
				if($searchkey=='songs')
				{
					$sdata = $obj->searchdata($searchkey,$searchterm);
					$snum=sizeof($sdata);
				}
			}
			else
			{
				$vdata = $obj->searchdata('video',$searchterm);
				$wdata = $obj->searchdata('wallpapers',$searchterm);
				$sdata = $obj->searchdata('songs',$searchterm);
				$vnum=sizeof($vdata);
				$wnum=sizeof($wdata);
				$snum=sizeof($sdata);
			}
			unset($_POST['submit']);
		}
		
		if(isset($_GET['q']))
		{
			$q=$_GET['q'];
			$vdata = $obj->searchbyalpha('video',$q);
			$wdata = $obj->searchbyalpha('wallpapers',$q);
			$sdata = $obj->searchbyalpha('songs',$q);
			$vnum=sizeof($vdata);
			$wnum=sizeof($wdata);
			$snum=sizeof($sdata);
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: watch and upload your favourite video.</title>
<link href="css/main.css" type="text/css" rel="stylesheet" />
</head>
<body>
	<table cellpadding="0" class="indextab" cellspacing="0" >
		<tr>
			<td colspan="2"><?php include("include/head.php"); ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
		<form action="" method="post" name="search">
		<td align="center">	
			<table>
				<tr>
					<td></td>
					<td colspan="2" align="center" style="font-weight:bold; text-decoration:underline;">Search by Alphabates</td>
					<td></td>
				</tr>
					<tr>
						<th colspan="4">
							<?php 
								$alpha = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
								for($i=0;$i<26;$i++)
								{
									echo "<a class='keysearch' href='?q=".$alpha[$i]."'>".$alpha[$i]."</a>&nbsp;&nbsp;&nbsp;";
								}
							?>
						</th>
					</tr>
				</table>
			</td>
		</form>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table border="0" width="99%">
					<tr>
						<th class="headth" width="33%">Video</th>
						<th class="headth" width="33%">Wallpapers</th>
						<th class="headth" width="33%">Songs</th>
					</tr>
					<tr>
						<th width="33%" align="left" valign="top">
							<?php
								if(isset($vdata) && $vdata!="")
								{ 
								for($i=0;$i<$vnum;$i++)
									{
							 ?>
							 	<table cellpadding="4" cellspacing="0" style="border:1px solid #000000; -moz-border-radius:0px 10px 10px 0px; -moz-box-shadow:0px 0px 10px 0px #000000 inset;" >
								<tr>
									
                <td rowspan="2" valign="top"> <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="136" height="148" id="FLVPlayer">
                    <param name="movie" value="FLVPlayer_Progressive.swf" />
                    <param name="salign" value="lt" />
                    <param name="quality" value="high" />
                    <param name="scale" value="noscale" />
                    <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=video/<?php echo $vdata[$i]['url']; ?>&autoPlay=false&autoRewind=true" />
                    <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=video/<?php echo $vdata[$i]['url']; ?>&autoPlay=false&autoRewind=true" quality="high" scale="noscale" width="136" height="148" name="FLVPlayer" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /> 
                  </object></td>
									<td valign="top" height="35px" style="border-bottom:1px solid #000000;">
										<a href="view.php?video=<?php echo $vdata[$i]['url']; ?>&&<?php if(isset($searchkey)){ ?>skey=<?php echo $searchkey; ?>&&sterm=<?php echo $searchterm; ?><?php } else if(isset($q)) { ?>q=<?php echo $q; } ?>" class='keysearch' title="<?php echo $rows[$i]['title']; ?>"><?php echo $vdata[$i]['title']; ?></a>
									</td>
								</tr>
								<tr>
									<td style="font-size:10px;" valign="top" align="justify">
										<?php echo $vdata[$i]['description']; ?>
									</td>
								</tr>
								</table>
								<?php
								}
								}
								else
								{
							?>
								<div class="red">No Data Found in Database.</div>
							<?php
								}
							?>
						</th>
						<?php 
							if(isset($wdata) && $wdata!="")
							{
								echo "<th  width='33%' valign='top' style='padding-left:20px;'>";
							for($i=0;$i<$wnum;$i++)
									{
							 ?>
						<div style="border:1px solid #000000; width:130px; -moz-border-radius:7px; -moz-box-shadow:0px 0px 5px 0px #000000; margin:5px; float:left; height:102px;"><img src="wallpaper/<?php echo $wdata[$i]['url']; ?>" title="<?php echo $wdata[$i]['title']; ?>" alt="<?php echo $wdata[$i]['title']; ?>" width="120px" height="100px" border="0"/></div>
						<?php
							}
							}
							else
							{
							echo "<th  width='33%' valign='top'>";
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
						<th width="33%" valign="top">
						<?php 
							if(isset($sdata) && $sdata!="")
							{
							for($i=0;$i<$snum;$i++)
									{
							 ?>
						 <table class="vidtable1" cellpadding="5" cellspacing="0">
							 <tr>
							 <td width="80px" rowspan="2">
							 <img src="images/images3.jpeg" width="80px" height="80px" alt="<?php echo $sdata[$i]['title']; ?>" title="<?php echo $sdata[$i]['title']; ?>" />
							 </td>
							 <td valign="top" align="left" height="35px" style="border-bottom:1px solid #000000;">
										<a href="view.php?songs=<?php echo $sdata[$i]['url']; ?>&&<?php if(isset($searchkey)){ ?>skey=<?php echo $searchkey; ?>&&sterm=<?php echo $searchterm; ?><?php } else if(isset($q)) { ?>q=<?php echo $q; } ?>" class='keysearch' title="<?php echo $sdata[$i]['title']; ?>"><?php echo $sdata[$i]['title']; ?></a>
									</td>
							</tr>
							<tr>
							<td style="font-size:10px;" valign="top" width="250" align="justify">
										<?php echo $sdata[$i]['description']; ?>
									</td>
							</tr>
							</table>
						<?php
							}
							}
							else
							{
						?>
							<div class="red">No Data Found in Database.</div>
						<?php
							}
						?>
						</th>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
