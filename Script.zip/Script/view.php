<?php
		if(isset($_GET['video']))
		{
			$url = $_GET['video'];
			$plat='video';
		}
		else if(isset($_GET['songs']))
		{
			$url = $_GET['songs'];
			$plat='song';
		}		
		else
		{
			header("Location:index.php");
			die;
		}
		if(isset($_GET['q'])){ $q=$_GET['q']; }
		if(isset($_GET['skey']))
		{
		 	$searchkey=$_GET['skey'];
			$searchterm=$_GET['sterm'];
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: watch your favourite video.</title>
<script>
	function login()
		{
			alert('Login first for download AND go your account and download your wishes.\n\nIf you are not register user then do free register AND download video.\n\nBe Enjoy with Video,Songs & Wallpapers.');
			return false;
		}
</script>
<link href="css/main.css" type="text/css" rel="stylesheet" />
<script type="text/javascript">
function MM_CheckFlashVersion(reqVerStr,msg){
  with(navigator){
    var isIE  = (appVersion.indexOf("MSIE") != -1 && userAgent.indexOf("Opera") == -1);
    var isWin = (appVersion.toLowerCase().indexOf("win") != -1);
    if (!isIE || !isWin){  
      var flashVer = -1;
      if (plugins && plugins.length > 0){
        var desc = plugins["Shockwave Flash"] ? plugins["Shockwave Flash"].description : "";
        desc = plugins["Shockwave Flash 2.0"] ? plugins["Shockwave Flash 2.0"].description : desc;
        if (desc == "") flashVer = -1;
        else{
          var descArr = desc.split(" ");
          var tempArrMajor = descArr[2].split(".");
          var verMajor = tempArrMajor[0];
          var tempArrMinor = (descArr[3] != "") ? descArr[3].split("r") : descArr[4].split("r");
          var verMinor = (tempArrMinor[1] > 0) ? tempArrMinor[1] : 0;
          flashVer =  parseFloat(verMajor + "." + verMinor);
        }
      }
      // WebTV has Flash Player 4 or lower -- too low for video
      else if (userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 4.0;

      var verArr = reqVerStr.split(",");
      var reqVer = parseFloat(verArr[0] + "." + verArr[2]);
  
      if (flashVer < reqVer){
        if (confirm(msg))
          window.location = "http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash";
      }
    }
  } 
}
</script>
<style type="text/css">
<!--
.style1 {font-size: 18px; color:#FFFFFF; text-transform:uppercase;}
-->
</style>
</head>
<body onload="MM_CheckFlashVersion('7,0,0,0','Content on this page requires a newer version of Macromedia Flash Player. Do you want to download it now?');">
	<table cellpadding="0" class="indextab" cellspacing="0" >
		<tr>
			<td colspan="2"><?php include("include/head.php"); ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<?php if($plat=='video') { ?>
		<tr>
			<td align="center"><a href="search.php?<?php if(isset($searchkey)){ ?>skey=<?php echo $searchkey; ?>&&sterm=<?php echo $searchterm; ?><?php } else if(isset($q)) { ?>q=<?php echo $q; } ?>" class="style1">Go Back <img border="0" src="images/go_back.png" /> to VIDEO</a></td>
		</tr>
		<tr>
			<td colspan="2" align="center">
			  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="472" height="501" id="FLVPlayer">
                  <param name="movie" value="FLVPlayer_Progressive.swf" />
                  <param name="salign" value="lt" />
                  <param name="quality" value="high" />
                  <param name="scale" value="noscale" />
                  <param name="FlashVars" value="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=video/<?php echo $url; ?>&autoPlay=false&autoRewind=true" />
                  <embed src="FLVPlayer_Progressive.swf" flashvars="&MM_ComponentVersion=1&skinName=Halo_Skin_3&streamName=video/<?php echo $url; ?>&autoPlay=false&autoRewind=true" quality="high" scale="noscale" width="472" height="501" name="FLVPlayer" salign="LT" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />                
</object>			
		</td>
		</tr>
		<?php }
			else
			{
		 ?>
		 	<tr>
				<td align="center"><a href="search.php?<?php if(isset($searchkey)){ ?>skey=<?php echo $searchkey; ?>&&sterm=<?php echo $searchterm; ?><?php } else if(isset($q)) { ?>q=<?php echo $q; } ?>" class="style1">Go Back <img border="0" src="images/go_back.png" /> to VIDEO</a></td>
			</tr>
		 	<tr>
				<td align="center">
									<embed type="application/x-shockwave-flash" wmode="transparent" src="http://www.google.com/reader/ui/3523697345-audio-player.swf?audioUrl=../song/<?php echo $url; ?>" height="27" width="320"></embed>				</td>
			</tr>
		 <?php
		 	}
		 ?>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" style="padding:3px;" name="download" value="Search" id="download" class="downloadbnt" onclick="return login();" title="download video <?php echo $url; ?>"/>
			</td>
		</tr>
	</table>
</body>
</html>
