<?php
include("admin/include/Connection.php");
$selsite	= "SELECT * FROM tbl_siteconfig";
$ressite 	= mysql_query($selsite);
$rowsite = mysql_fetch_array($ressite);
$sitename  	= $rowsite['Site_name'];
$sel	= "SELECT * FROM tbl_video";
$res	= mysql_query($sel);
$row	= mysql_fetch_array($res);
$videoid	= $row['video_id'];
$title		= $row['video_title'];
$link		= $row['video_link'];
$desc		= $row['video_des'];
$status1	= $row['Status'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo $sitename;?> :: Video</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="css/style2.css" />
<link rel="stylesheet" type="text/css" href="css/style1.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="css/style1.css" type="text/css" rel="stylesheet">
<script language="javascript" src="javascript/swfobject.js"></script>
<script type="text/javascript" src="javascript/login.js"></script>
<script type="text/javascript" src="admin/javascript/general.js"></script>
</head>
<body>
	<?php include("include/top.php");?>	
	<div id="content">
		<?php include("search.php");?>
		<div id="info">			
			<table border="0" cellspacing="0" cellpadding="0" align="center" width="100%">
												<tr><td>&nbsp;</td></tr>
												<tr><td style="padding-left:385px;"><font color="#330000" size="2"><b><span class="link3">Video</span></b></font></td></tr>
												<tr height="10px"><td>&nbsp;</td></tr>
												<tr>
													<td align="left" style="padding-left:50px;">
														<table border="0" cellpadding="0" cellspacing="0" width="93%" 
														    align="center">
															<tr>
																<td align="left" style="padding-left:320px;" nowrap="nowrap"><font size="+1"><?php echo $title;?></font></td>
															</tr>
															<tr>
																<td height="30px;"></td>
															</tr>
													<tr>
														<td>  
																<div style="padding-left:130px;">
																<div id="player">
																	<script type='text/javascript' >
																	var so = new SWFObject('swf/player.swf','ply','400','250',
																	                        '9','#ffffff');
																	so.addParam('allowfullscreen','true');
																	so.addParam('allowscriptaccess','always');
																	so.addParam('wmode','opaque');
																	so.addVariable('file','video/job.swf');
																	so.write('player');
																	</script>
																</div>
															    </div>
														</td>	
														</tr>
													</table>
													</td>
												</tr>
												<tr><td height="10px"></td></tr>
											</table>
		</div>
		<?php include("include/block1.php");?>	
		<?php include("include/infoblock.php");?>	
	</div>
	<?php include("include/footer.php");?>
</body>
</html>


