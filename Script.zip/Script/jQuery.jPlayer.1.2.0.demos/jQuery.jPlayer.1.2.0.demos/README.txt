jPlayer 1.2.0 Demos
-------------------

Upload these files to a server online or place on a localhost server,
otherwise the Flash will encounter security errors if you attempt
to access the HTML files directly.


Directories:
------------

"js": Contains the jPlayer plugin. If you rename/move this, set the {swfPath:"new/path"} appropriately.

"skin": Contains the Blue Monday skin

"jquery-ui-1.7.1.custom": Contains the jQueryUI and jQuery 1.3.2 used with "demo-07.htm".


Related Links:
--------------

For Documentation see:
jPlayer Website: http://www.happyworm.com/jquery/jplayer/

For support requests use:
jPlayer Google Group: http://groups.google.com/group/jplayer
