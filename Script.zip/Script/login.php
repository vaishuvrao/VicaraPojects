<?php
	session_start();
		include("include/database.php");
		include("include/register_class.php");
		$msg='';
		$obj=new general();
		if(isset($_POST['login']) && $_POST['login']=='Log in')
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
			if($username=="" || $password=="")
			{
				header("location:?msg=Enter your valid username and Password");
				exit;
			}
			else
			{
				$result=$obj->userauthority($username,$password);
				if($result==0)
				{
					$msg='Username AND Password combination has not Exist.';
				}
				else
				{
					header("location:user/");
				}
			}
		}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<LINK rel="SHORTCUT ICON" href="images/shortcut.jpg">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MyTube :: watch and upload your favourite video.</title>
<script language="javascript">
	function validform()
	{
		var username = document.getElementById('username');
		var password = document.getElementById('password');
		if(username.value=="")
		{
			alert('Enter valid user name.');
			username.focus();
			return false;
		}
		if(password.value=="")
		{
			alert('Enter valid Password.');
			password.focus();
			return false;
		}
		return true;
	}
</script>
</head>
<body>
	<table cellpadding="0" class="indextab" cellspacing="0"  width="100%" height="100%" >
		<tr>
			<td colspan="2"><?php include("include/head.php"); ?></td>
		</tr>
		<tr>
			<td width="70%" align="justify" style="font-weight:bold;">
			<div style="width:600px;"><h2>About sites</h2>
			<p style=font-weight:bold; font-size:50px;" align="justify">Biztech Consultancy is an Indian web development company providing website design and website develpment services to clients across the globe. we are an Indian based offshore development center offering web solutionsat reasonable rates for web applications development, website designning,web site maintenance, onlone shopping cart, solutions,software davelopment, web directory development to global business of all sizes.</p>
			<p style="font-weight:bold" align="justify">Though our core technology is Php Development, we provide all sorts of technology solutions. We provide all kinds of dynamic application, content management system, shopping cart application, static application or corporate application. Our professional developers and designers help to develop and design database driven customised web applications using the latest technologies like Php, Cakephp, Ajax, jQuery, python, magento, sugar CRM and net office.</p></div></td>
			
			<td>
				<form action="" method="post" name="login"> 
				<table width="100%" border="0" cellpadding="3" cellspacing="0">
					<tr>
						<th colspan="3" id="error"><?php echo $msg; ?></th>
					</tr>
					<tr>
						<th colspan="3">Log in</th>
					</tr>
					<tr>
						<td width="33%">User Name </td>
						<td width="52%"><input type="text" name="username" id="username" class="inputtype" /></td>
						<td width="15%" id="compalsory">*</td>
					</tr>
					<tr>
						<td>Password </td>
						<td><input type="password" name="password" id="password" class="inputtype" /></td>
						<td id="compalsory">*</td>
					</tr>
					<tr>
						<td></td>
						<th><input type="submit" name="login" value="Log in" id="login" class="loginbtn" onclick="return validform();" /></th>
					</tr>
					<tr>
					<td height="10"></td>
					</tr>
					<tr>
						<td colspan="3" align="center"><a href="register.php" class="keysearch">New User get Free Registration</a></td>
					</tr>
					<tr>
						<td height="10"></td>
					</tr>
					<tr>
						<td  colspan="3" align="center"><a href="forget.php" class="keysearch">I can't access my account ??</a></td>
					</tr>
				</table>
				</form>
			</td>
		</tr>
	</table>
</body>
</html>
